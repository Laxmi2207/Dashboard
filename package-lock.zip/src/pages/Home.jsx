import React from 'react'
import Sidenav from '../components/Sidenav'
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Navbar from '../components/Navbar';
import MyNavbar from '../components/MyNavbar';


export default function Home() {
  return (
    <>
   <MyNavbar/>
    <Box sx={{display: "flex"}}>
      <Sidenav/>
        <h1>Home</h1>
        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
       
      </Box>
        </Box>
    </>
  )
}
